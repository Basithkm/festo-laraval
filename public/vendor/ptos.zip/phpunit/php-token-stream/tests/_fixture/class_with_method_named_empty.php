<?php
class class_with_method_named_empty
{
    public function empty(): void
    {
    }
}
