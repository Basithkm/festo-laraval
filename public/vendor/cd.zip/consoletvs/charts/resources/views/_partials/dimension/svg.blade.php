<style>
#{{ $model->id }} > svg {
    @include("charts::_partials.dimension.css")
}
</style>
