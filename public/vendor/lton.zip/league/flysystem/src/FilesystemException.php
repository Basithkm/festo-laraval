<?php

namespace League\Flysystem;

interface FilesystemException
{
}
