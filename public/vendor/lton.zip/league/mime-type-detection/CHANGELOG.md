# Changelog

## 1.7.0 - 2021-01-18

### Added

- Added a `bufferSampleSize` parameter to the `FinfoMimeTypeDetector` class that allows you to send a reduced content sample which costs less memory.

## 1.6.0 - 2021-01-18

### Changes

- Updated generated mime-type map
