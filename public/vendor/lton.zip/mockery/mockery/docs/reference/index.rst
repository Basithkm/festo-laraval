Reference
=========

.. toctree::
    :hidden:

    startup_methods
    expectations
    argument_validation
    partial_mocks
    public_properties
    public_static_properties
    pass_by_reference_behaviours
    demeter_chains
    object_recording
    final_methods_classes
    magic_methods
    mockery/index

.. include:: map.rst.inc
