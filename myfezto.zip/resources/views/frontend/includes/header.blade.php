

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/css/flag-icon.min.css" rel="stylesheet" />

<script src="{{url('front-end/js/jquery-3.3.1.js')}}"></script>



<!--newfeature dropdown flag--->
<script>
  $(document).ready(function() {
    $('.selectpicker').selectpicker();
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $('#country').change(function(){
     var code=$(this).val();
     $('#countrycode').val(code);
    });
    
    
    
   $('#searchQueryInput').keyup(function(){
   
 $('#home').hide();

var key=$(this).val();
    $.ajax({

               type:'get',
               url:'{{url('searchproduct')}}',
               data:({key:key}),
               success:function(data){

$('#srchrlt').html(data);

                 }

    });

}); 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   
  });
  $(".popupcancel").click(function(){
    // alert('ok');
   $(".popupcancel").fadeOut().removeClass("active");
});
</script>

<div class="container-fluid top  ps-0 pe-0 " style="z-index:9999">
        <div class="row">
            
            <div class="col-md-2 col-sm-12 col-12 logo">
            <div> 
    <button class="hamburger-btn" onclick="toggleSidebar()">&#9776;</button>
     </div>  
 
             <div> 
            <a  href="{{url('/')}}">
                 <img src="{{URL::to('/')}}/front-end/images/itcityimages/logo-it.png" alt="">
            </a>
            </div> 
              <div class="top-icons">
                  
                <div class="top-cart-icons">
                <a class="cart-btn" href="{{url('my-cart')}}">
                 <img src="{{URL::to('/')}}/front-end/images/itcity/shopping-cart.png" alt="">
                  <div id="mcart" class="cart-items-value">{{Cart::content()->groupBy('id')->count()}}</div>
                  </a>
                </div>
                <div class="top-user-icons">
                  @if(session('username'))
                  <div class=" hover-box" >
                   <a class="cart-btn" href="{{url('my-account')}}">
                        <img src="{{URL::to('/')}}/front-end/images/itcity/user.png" alt="">
                    </a>
                    </div>
                  @else
                <a class="cart-btn" href="{{url('my-login')}}">
                     <img src="{{URL::to('/')}}/front-end/images/itcity/user.png" alt="">
                    </a>
                    @endif
                </div>
            </div>
            </div>
            <div class="col-md-8 header">

                <div class='search'>
                <form action="{{url('/search')}}" method="get">
                     {{ csrf_field() }}
                    <div class="searchBar">

                        <input id="searchQueryInput"  name="value" type="text" placeholder="Search Products,Brands and More" />
                        <div className='d-flex'>

                            <button id="searchQuerySubmit" type="submit" name="searchQuerySubmit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
                </div>
            </div>

            <div class="col-md-2 d-flex header-icons ">
                  
                <div class="cart-icons">
                <a class="cart-btn" href="{{url('my-cart')}}">
                  <i class="fas fa-shopping-cart"></i>
                  <div id="mcartweb" class="cart-items-value">{{Cart::content()->groupBy('id')->count()}}</div>
                  </a>
                </div>
                <div class="user-icons">
                  @if(session('username'))
                  <div class=" hover-box" >
                   <a href="{{url('my-account')}}"><i class="fas fa-user"></i></a>
                    </div>
                  @else
                <a class="cart-btn" href="{{url('my-login')}}">
                    <i class="fas fa-user"></i>
                    </a>
                    @endif
                </div>
            </div>
        </div>

        <nav class="main-navbar navbar navbar-expand-lg navbar-light p-0">
            <div class="container">
 
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">


                    <ul class="navbar-nav m-auto mb-2 mb-lg-0">
                         
                    <li class="nav-item">
                           <div class="dropdown">
                    <a href="{{url('category-products/mens-wear')}}">Men</a>
                    <div class="dropdown-content ">
                        <div class="d-flex">
                      <ul>
                      <a href="{{url('category-products/men')}}"> <h4>Top Wear</h4></a>
                          <li>
                             Topers 
                          </li>
                          <li>
                             Jumbsuits
                          </li>
                          <li>
                             Topers 
                          </li>
                      </ul>
                       <ul>
                          <h4>Top Wear</h4>
                          <li>
                             Topers 
                          </li>
                          <li>
                             Jumbsuits
                          </li>
                          <li>
                             Topers 
                          </li>
                      </ul>
                      </div>
                    </div>
                  </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " aria-current="page" href="{{url('category-products/women')}}">Women</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/computers')}}">Kids</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/Footweare')}}">Footweare</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/Bag')}}">Bag</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/Kitchen & Home')}}">Kitchen & Home</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/Sports')}}">Sports</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/Toys')}}">Toys</a>
                        </li>
                       
                </div>
            </div>
        </nav>
      
<!--Mobileresponsive-->
 
  <div class="sidebar" id="sidebar">
      <span  class="popup-close" onclick="myFun()">&times;</span>
   <div>
                    <ul class="navbar-nav m-auto mb-2 mb-lg-0 py-5 px-3">
                        <h6>All Categories</h6>
                        <li class="nav-item">
                            <a class="nav-link " aria-current="page" href="{{url('category-products/accessories')}}">Accessories</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/computers')}}">Computers</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/mobiles')}}">Mobiles</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/tablets')}}">Tablets</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/home-appliances')}}">Home Appliances</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/watches-perfume')}}">Watches & Perfumes</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/travel-bags')}}">Travel Bags</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/personal-care')}}">Personal Care</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/cameras-drones')}}">Cameras & Drones</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="{{url('category-products/gaming')}}">Game Zone</a>
                        </li>
                        <hr>
                                               <li class="nav-item">
                            <a class="nav-link" href="" style="font-weight: 600;">Download App</a>
                        </li>
                         <li class="nav-item">
                          <a href='https://play.google.com/store/apps/details?id=com.itcityonlinestore.itcity_online_store&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'><img style="width:100px;" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/></a>
                        </li>
                          
                        <!--<li class="nav-item">-->
                        <!--    <a class="nav-link" href="" style="font-weight: 600;">Add ITCITY To Home Screen  </a>-->
                        <!--</li>-->
                        
                        </ul>
                        

                </div>
  </div>
  
  
  <div class="content">
    <!-- Main content goes here -->
  </div>
  

<section class="country-lang">
    <div class="container-fluid" style="padding:'0px'">
      <div class="row">

        <div class="col-6 text-start">


  


        </div>
        
        <div id="popup" class="popupup">
       <form action="{{url('country-change')}}" method="post">
        {{csrf_field()}}
        <h2>Are you sure want to change your country</h2>
         <input type="hidden" id="countrycode" class="countrycode" name="countrycode" value="KWD" readonly>
        <button type="submit" class="popupok" >Yes</button>
        <button type="button" class="popupcancel" onclick="myFunction()">No</button>
       </form>
       </div>
        <div class="col-6 text-end">
            @if(session('locale')=='ar')
            <a style="text-decoration:none;color:white;" class="col-6 text-end" href="{{url('lang/change/en')}}">English</a>

            @else
            <a style="text-decoration:none;color:white;" class="col-6 text-end" href="{{url('lang/change/ar')}}">عربى</a>

            @endif
  
        </div>
      </div>
    </div>
  </section>
    </div>
    

<div class="container">
  <div id="srchrlt" class="d-flex flex-wrap"></div>
</div>



<script>
  function showPopupcountry() {
  var popup = document.getElementById('popup');
  popup.style.display = 'flex';
}
</script>



<script>
  function myFunction() {
  var popup = document.getElementById('popup');
   popup.style.display = 'none';
}
</script>



<!---Mobileresponsive-->
<script>

    function toggleSidebar() {
        
        // var sidebar = document.getElementById("sidebar");
//   sidebar.style.display = 'block';

  var sidebar = document.getElementById("sidebar");
   sidebar.style.display = 'block';
   var sidebar = document.getElementById("sidebar");
  var content = document.getElementsByClassName("content");
  sidebar.classList.toggle("active");

  content.classList.toggle("active");
  
//   event.preventDefault();
}
</script>


<script>
function myFun() {
  var sidebar = document.getElementById("sidebar");
  sidebar.style.display = 'none';
}
</script>
<script>
    if ($(".dropdown").length) {
    $(document).on("click", ".dropdown-menu .dropdown-item", function (e) {
        e.preventDefault();
        if (!$(this).hasClass("active")) {
            var swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: "btn btn-primary",
                    cancelButton: "btn btn-danger me-3",
                },
                buttonsStyling: false,
            });
            swalWithBootstrapButtons
                .fire({
                    title: "Are you sure?",
                    text: "Do you really want to change your current language!",
                    icon: "warning",
                    confirmButtonText: "<i class='fas fa-check-circle me-1'></i> Yes, I am!",
                    cancelButtonText: "<i class='fas fa-times-circle me-1'></i> No, I'm Not",
                    showCancelButton: true,
                    reverseButtons: true,
                    focusConfirm: true,
                })
                .then((result) => {
                    if (result.isConfirmed) {
                        if (!$(this).hasClass("active")) {
                            $(".dropdown-menu .dropdown-item").removeClass("active");
                            $(this).addClass("active");
                            $(this)
                                .parents(".dropdown")
                                .find(".btn")
                                .html("<span class='flag-icon flag-icon-us me-1'></span>" + $(this).text());
                        }
                        Swal.fire({
                            icon: "success",
                            title: "Amazing!",
                            text: "Your current language has been changed successfully.",
                            showConfirmButton: false,
                            timer: 1500,
                        });
                    }
                });
        }
    });
}
</script>
<script>
//     document.addEventListener("DOMContentLoaded", function() {
//   var popup = document.getElementById('popup-blink');
//   setTimeout(function() {
//     popup.style.display = 'block';
//   }, 1000); // 5 minutes in milliseconds
// });
// 
</script>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



