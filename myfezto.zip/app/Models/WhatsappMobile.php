<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
class WhatsappMobile extends Model
{
    protected $table = 'whatsapp_mobile';
    use HasFactory;
}
