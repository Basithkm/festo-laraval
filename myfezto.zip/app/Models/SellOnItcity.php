<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
class SellOnItcity extends Model
{
    protected $table = 'sell_on_itcity';
    use HasFactory;
}
