<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use Illuminate\Support\Facades\Auth;
class SampleController extends Controller
{
    //
    public function index()
        {
            try {
            
        } catch (\Exception $e) {
            return $e->getMessage();
        }
        }

        public function create()
        {
            try {
              
        } catch (\Exception $e) {
            return $e->getMessage();
        }
        }
        public function store(Request $request)
        {
          
        
            try {
               
               

        } catch (\Exception $e) {
            return $e->getMessage();
        }
        }

        public function edit(Request $request,$id)
        {
            try {
         
        } catch (\Exception $e) {
            return $e->getMessage();
        }
        }
        public function update(Request $request)
        {
          
           
            try {
            
              
              
            
        } catch (\Exception $e) {
            return $e->getMessage();
        }
        }

        public function active(Request $request,$id)
        {
          
           
            try {
               
              
           
        } catch (\Exception $e) {
            return $e->getMessage();
        }
        }




      
    
}
