
<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
  <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    
                <div class="row">
                    <div class="col-6 col-md-6 col-sm-6 col-xs-12" >
                             <h4 class="card-title">Product Detail</h4>
                    </div>
                    <div class="col-6 col-md-6 col-sm-6 col-xs-12 exelbuton" style="text-align:end;">
                           
                    </div>
                       
                   
                </div>
                 
                 
                  <div class="row">
                  <div class="col-6 col-md-6 col-sm-6 col-xs-12" >
                    <p class="card-description">
                  <img src="<?php echo e(url('/uploads/product/thumb_images/'.$view_prod->product_image)); ?>" alt="" width="130px" height="130px">
                  </p>

                    </div>
                  <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-6 col-sm-6 col-xs-12" >
                    <p class="card-description">
                  <img src="<?php echo e(url('/uploads/product/thumb_images/'.$mg->images)); ?>" alt="" width="130px" height="130px">
                  </p>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-6 col-sm-6 col-xs-12" >
                    <p class="card-description">
                    <?php if($view_prod->product_qty<='0'): ?>

<label style="color:red;"><b>Out of Stock</b></label>

<?php else: ?>
               <lable style="color: green;">Avilable Stock</lable>   <lable style="color: red;">:<?php echo e($view_prod->product_qty); ?></lable>
                <?php endif; ?>
                  </p>
                  <lable>Current Status:</lable>
                  <?php  
                                        $stat = $view_prod->status;
                                        if ($stat=='0'||$stat==null) { ?>

                                            <img src="<?php echo e(url('/uploads/images/disable.png')); ?>" alt="" width="30px" height="30px">
 <a href="<?php echo e(url('product-active/'.$view_prod->id)); ?>" class="btn btn-success">Active</a>
                                       <?php }else{ ?>

                                        <img src="<?php echo e(url('/uploads/images/enable.png')); ?>" alt="" width="30px" height="30px">
                                          <a href="<?php echo e(url('product-deactive/'.$view_prod->id)); ?>" class="btn btn-danger">Deactive</a>

                                     <?php  }
                                        ?>
                    </div>
                      
                  </div>
                  <?php
                                            $feat = $view_prod->featured;
                                            if ($feat=='0') { ?>
                                                 <a class="btn btn-primary" href="<?php echo e(url('pro-set-featured/'.$view_prod->id)); ?>" onclick="return confirm('Are you sure you want to make this product featured');">Unfeatured</a>
                                          <?php   }else { ?> 
                                            <a href="<?php echo e(url('pro-set-unfeatured/'.$view_prod->id)); ?>" onclick="return confirm('Are you sure you want to remove this product from featured list');" class="btn btn-secondary">Featured</a>
                                         <?php }
                                            ?>
                       <a href="<?php echo e(url('add-image/'.$view_prod->id)); ?>" class="btn btn-success">
                          Add Image
                        </a>
                        <?php if($view_prod->parent_id==0): ?>
                         <a href="<?php echo e(url('add-color/'.$view_prod->id)); ?>" class="btn btn-warning">
                          Add Color
                        </a>
                        <?php endif; ?>
                        <a href="<?php echo e(url('edit-product/'.$view_prod->id)); ?>" class="btn btn-info">
                         Edit
                        </a>
                        <a href="<?php echo e(url('reset-stock/'.$view_prod->id)); ?>" class="btn btn-dark">
                         Reset Stock
                        </a>
                        <a href="<?php echo e(url('delete-product/'.$view_prod->id)); ?>" class="btn btn-danger">
                         Delete
                        </a>
                        <a href="<?php echo e(url('add-size/'.$view_prod->id)); ?>" class="btn btn-outline-info btn-fw">
                         Add Size
                        </a>
                           <a href="<?php echo e(url('add-stock/'.$view_prod->id)); ?>" class="btn btn-success">
                          Add Stock
                        </a>
                        <div class="table-responsive">
                 
                  <div class="table-responsive">
                    <table class="table table-hover">
                    <tbody>
                        <tr>
                       
                                  
                                        <td>ID</td>
                                        <td><?php echo e($view_prod->product_id); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Name</td>
                                        <td><?php echo e($view_prod->product_name); ?></td>      
                                        </tr>
                                        <tr>
                                        <td>Sort</td>
                                        <td><?php echo e($view_prod->sort_order); ?></td>      
                                        </tr>
                                        <tr>
                                        <td>Category</td>
                                       <td>  
                                
                             </td>
                                         </tr>
                                        
                                         <tr>
                                        <td>Description</td>
                                       <td><?php echo $view_prod->product_desc; ?></td>
                                         </tr>
                                         <tr>
                                        <td>Product Price</td>
                                       <td><?php echo e($view_prod->product_price); ?></td>
                                         </tr>
                                         <tr>
                                        <td>Product Price Offer	</td>
                                       <td><?php echo e($view_prod->product_price_offer); ?></td>
                                         </tr>
                                         <tr>
                                        <td>Product Premium Offer	</td>
                                       <td><?php echo e($view_prod->product_premium_offer); ?></td>
                                         </tr>
                                         

                            
                           
            
                        
                       
                      </tbody>
                    </table>

                  </div>
                  <div class="table-responsive">
                    <?php if($view_prod->parent_id==0): ?>
                    <table class="table table-hover" >
                      <thead>
                        <tr>
                       
                                  
                                        <th>ID</th>
                                        <th>Sort</th>
                                        <th>Name</th>
                                        <th>Action</th>
                                        
                                       
                        </tr>
                      </thead>
                      <tbody>
                          
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          
                       
                             <td><?php echo e($product->product_id); ?></td>
                             <td><?php echo e($product->sort_order); ?></td>
                             <td><?php echo e($product->product_name); ?></td>
                            <td> <a href="<?php echo e(url('view-product/'.$product->id)); ?>" class="btn btnsmall btn-outline-secondary btn-icon-text" >View</a>
                            <a href="<?php echo e(url('add-color/'.$product->id)); ?>" class="btn btnsmall btn-outline-warning btn-icon-text">
                          Add Color
                          <i class="ti-reload btn-icon-prepend"></i>

                        </a>
                        <a href="<?php echo e(url('add-image/'.$product->id)); ?>" class="btn btnsmall  btn-outline-secondary btn-icon-text">
                          Add Image
                          <i class="ti-reload btn-icon-prepend"></i>

                        </a>
                          </td>
                           
                        </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                       
                      </tbody>
                    </table>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>
            
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
    $('#value-table').DataTable();
} );
let button = document.querySelector("#myexel");

button.addEventListener("click", e => {
  let table = document.querySelector("#value-table");
  TableToExcel.convert(table);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/product/view-product.blade.php ENDPATH**/ ?>