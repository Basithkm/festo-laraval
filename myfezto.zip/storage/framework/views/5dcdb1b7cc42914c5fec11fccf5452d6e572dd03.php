<div class="footer-icons  mobilediv">
    <div class="footer-icons-link nav">
     
        <ul class="navbar-nav" style="display:contents;">
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(url('/')); ?>">
               <img style="width:15px;" src="<?php echo e(URL::to('/')); ?>/front-end/images/itcity/home.png" alt="">
               <h6><?php echo e(__('main.Home')); ?></h6>
               <!--Home-->
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('search')); ?>">
                <img style="width:15px;" src="<?php echo e(URL::to('/')); ?>/front-end/images/itcity/search.png" alt="">
              <h6><?php echo e(__('main.Search')); ?></h6>  
              <!--Search-->
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('category')); ?>">
                <img style="width:15px;" src="<?php echo e(URL::to('/')); ?>/front-end/images/itcity/categories.png" alt="">
              <h6><?php echo e(__('main.Categories')); ?></h6>  
              <!--Categories-->
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('my-cart')); ?>">
                <img style="width:15px;" src="<?php echo e(URL::to('/')); ?>/front-end/images/itcity/shopping.png" alt="">
                <h6><?php echo e(__('main.Cart')); ?></h6> 
                <!--Cart-->
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link"  href="<?php echo e(url('my-account')); ?>">
            <img style="width:15px;" src="<?php echo e(URL::to('/')); ?>/front-end/images/itcity/userone.png" alt="">
            <h6><?php echo e(__('main.Profile')); ?></h6> 
            <!--Profile-->
               </a>
        </li>
    </ul>
    
    
    
        
 <!--       <div class="nav-item active">-->
 <!--           <a href="<?php echo e(url('/')); ?>">-->
 <!--               <i class="fas fa-home"></i>-->
 <!--<span class="sr-only">-->
 <!--                   (current)-->
 <!--               </span>-->
 <!--               <h6>Home</h6>-->
 <!--           </a></div>-->
 <!--       <div class="nav-item"><a eventkey="link-1" href="<?php echo e(url('search')); ?>">-->
 <!--               <i class="fas fa-search"></i>-->

 <!--               <h6>Search</h6>-->
 <!--           </a></div>-->
 <!--       <div class="nav-item"><a href="<?php echo e(url('category')); ?>">-->
 <!--               <i class="fas fa-th"></i>-->
 <!--               <h6>Categories</h6>-->
 <!--           </a></div>-->
 <!--       <div class="nav-item"><a href="<?php echo e(url('my-cart')); ?>">-->
 <!--               <i class="fas fa-cart-plus"></i>-->
 <!-- <img src="<?php echo e(URL::to('/')); ?>/front-end/images/itcity/shopping-cart.png" alt="">-->
 <!--               <h6>Cart</h6>-->
 <!--           </a></div>-->
 <!--       <div class="nav-item"><a href="<?php echo e(url('my-account')); ?>">-->

 <!--               <i class="fas fa-user"></i>-->

 <!--               <h6>Profile</h6>-->
 <!--           </a>-->
 <!--           </div>-->
    </div>
</div>



<div class="footer-div desktopview pt-3">
    <div class="container">
        <div class=" p-0 m-0 row">

            <div class=" p-0 m-0 col-lg-3 col-md-6 col-sm-6">
                <ul>
                    <img src="<?php echo e(URL::to('/')); ?>/front-end/images/itcityimages/main-logo-footer.png" alt="">


<address style="font-weight: 600;
    text-align: initial;">
 
<!--ITCity International Farwaniya<br>Habeeb Al munawar street<br>Maghateer complex<br>Mezzanine floor<br>Farwaniya,kuwait<br> Tel: +965 90019287</address>-->

                    <li><i class="fas fa-envelope" style="color:#f5831a"></i>info@itcityonlinestore.com</li>
                    <li><i class="fas fa-mobile-alt" style="color:#f5831a"></i> +965 90019287</li>
                    <li><i class="fas fa-map-marker-alt" style="color:#f5831a"></i> 
                    <?php echo e(__('main.IT_City')); ?><br><?php echo e(__('main.Habeeb_Al_munawar_street')); ?><br><?php echo e(__('main.Maghateer_complex')); ?><br><?php echo e(__('main.Mezzanine_floor')); ?><br><?php echo e(__('main.Farwaniya_kuwait')); ?></li>
                </ul>
            </div>
            <div class="p-0 m-0 col-lg-3 col-md-6 col-sm-6">
                <ul>
                    <h5><?php echo e(__('main.Information')); ?></h5>
                    <li><a href="<?php echo e(url('delivery-information')); ?>"><?php echo e(__('main.Delivery_Information')); ?></a></li>
                    <li><a href="<?php echo e(url('privacy-policy')); ?>"><?php echo e(__('main.Privacy_Policy')); ?></a></li>
                    <li><a href="<?php echo e(url('terms-conditions')); ?>"><?php echo e(__('main.Terms')); ?>&amp;<?php echo e(__('main.Condition')); ?></a></li>
                </ul>
            </div>
            <div class="p-0 m-0 col-lg-3 col-md-6 col-sm-6">
                <ul>
                    <h5><?php echo e(__('main.Categories')); ?></h5>
                    <li><a href="<?php echo e(url('category-products/accessories')); ?>"><?php echo e(__('main.Accessories')); ?></a></li>
                    <li><a href="<?php echo e(url('category-products/computers')); ?>"><?php echo e(__('main.Computers')); ?></a></li>
                    <li><a href="<?php echo e(url('category-products/mobiles')); ?>"><?php echo e(__('main.Mobiles')); ?></a></li>
                    <li><a href="<?php echo e(url('category-products/tablets')); ?>"><?php echo e(__('main.Tablets')); ?></a></li>
                    <li><a href="<?php echo e(url('category-products/home-appliances')); ?>"><?php echo e(__('main.Home_Appliances')); ?></a></li>
                    <li><a href="<?php echo e(url('category-products/watches-perfume')); ?>"><?php echo e(__('main.Watches')); ?> &amp; <?php echo e(__('main.Perfumes')); ?></a></li>
                    <li><a href="<?php echo e(url('category-products/travel-bags')); ?>"><?php echo e(__('main.Travel_Bags')); ?></a></li>
                    <li><a href="<?php echo e(url('category-products/personal-care')); ?>"><?php echo e(__('main.Personal_Care')); ?></a></li>
                    <li><a href="<?php echo e(url('category-products/cameras-drones')); ?>"><?php echo e(__('main.Cameras')); ?> &amp; <?php echo e(__('main.Drones')); ?> </a></li>
                    <li><a href="<?php echo e(url('category-products/gaming')); ?>"><?php echo e(__('main.Gaming')); ?></a></li>
                </ul>
            </div>
            <div class="p-0 m-0 col-lg-3 col-md-6 col-sm-6">
                <ul>
                    <h5>Service</h5>
                    <!-- <li><a href="<?php echo e(url('category')); ?>">Wish List</a></li> -->
                    <li><a href="<?php echo e(url('my-cart')); ?>"><?php echo e(__('main.Shopping_Cart')); ?></a></li>
                    <li><a href="<?php echo e(url('return-policy')); ?>"><?php echo e(__('main.Return_Policy')); ?></a></li>
                    <li><a href="<?php echo e(url('about-us')); ?>"><?php echo e(__('main.About_Us')); ?></a></li>
                </ul>
                <ul class="footersocial d-flex">
                    <!--style="color:#f48120"-->
                    <li ><a title="Connect us on Facebook" target="_blank" href="https://www.facebook.com/itcityonlinestore"><i  class="fab fa-facebook"></i></a></li>
                    <li ><a title="Connect us on Twitter" target="_blank" href="https://twitter.com/itcitykuwait"><i  class="fab fa-twitter-square"></i></a></li>
                    <li><a title="Connect us on youtube" target="_blank" href="https://www.youtube.com/channel/UCQKb_8AOnVB7euYZWoQke_w?view_as=subscriber"><i  class="fab fa-youtube"></i></a></li>
                    <li><a title="Connect us on Instagram" target="_blank" href="https://www.instagram.com/itcity_international/"><i  class="fab fa-instagram-square"></i></a></li>
                     <li><a title="Connect us on Instagram" target="_blank" href=""><i class="fab fa-tiktok"></i></a></li>
                       <li><a title="Connect us on Instagram" target="_blank" href=""><i class="fab fa-google-plus-square"></i></a></li>
                  
                </ul>
                 <ul class="footerplaystore">
                      <h6 style="color:#fff"><?php echo e(__('main.Download_App')); ?></h6>
              
                     
                     
                 <a href='https://play.google.com/store/apps/details?id=com.itcityonlinestore.itcity_online_store&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'><img style="width:160px;" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/></a>
                
                </ul>
            </div>

            <!--<div class="bottom-footer"><h6>© 2019 IT CITY ONLINE STORE </h6></div>-->


        </div>

    </div>
</div>

<!--<div class="container"><hr></div>-->

<div class="bottom-footer">
    <hr style="margin:0px;opacity:0.9;">
    <h6>© 2023 IT CITY ONLINE STORE </h6>
</div>
  
     <script>
        $(document).ready(function() {
            $('li').click(function() {
                $('li.nav-item.active').removeClass("active");
                $(this).addClass("active");
            });
        });
    </script>
      <script src="<?php echo e(url('front-end/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(url('front-end/js/scriptfont.js')); ?>"></script>
  <script src="<?php echo e(url('front-end/js/jquery.min.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/frontend/includes/footer.blade.php ENDPATH**/ ?>