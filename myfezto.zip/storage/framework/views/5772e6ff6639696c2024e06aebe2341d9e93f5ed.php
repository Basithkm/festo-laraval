<?php $__env->startSection('content'); ?>

<div class="main-panel">
<div class="content-wrapper">
<div class="col-12 grid-margin createtable">
              <div class="card">
                <div class="card-body">
           
                  
                        <div class="row">
                        <div class="col-md-6">
                                 <h4 class="card-title">Add Category</h4>
                        </div>
                           <div class="col-md-6 heading">
                             <a href="<?php echo e(URL::to('group-category/categories')); ?>" class="backicon"><i class="mdi mdi-backburger"></i></a>
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>
                    
                    <div class="row">
                    <br>
                   </div>
                
                  <div class="col-xl-12 col-md-12 col-sm-12 col-12">
           
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div><br />
          <?php endif; ?>
          
        </div>
                  <form class="form-sample"  action="<?php echo e(url('group-add-new-category')); ?>" method="post" enctype="multipart/form-data"  >
                          <?php echo e(csrf_field()); ?>

                    <div class="row">
                        
                      <div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label">Category Name</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <input type="text" name="category" class="form-control"  required="">
                          </div>
                        </div>
                      </div>
                                            
                      <div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label">Group Category</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <select class="form-control" name="sub_cate_name" required="">
                                          <option value="0">Select</option>
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->sub_cat_name); ?></option>
                                           

                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                        </select>
                          </div>
                        </div>
                      </div>
                        
                      </div>
              
                
                    
                    
                    
                
                <div class="submitbutton">
                    <button type="submit" class="btn btn-primary mb-2 submit">Submit<i class="fas fa-save"></i>


</button>
                    </div>
                    
                    
                    
                  </form>
                </div>
              </div>
            </div>
          </div>
            </div>
               
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/group-category/create.blade.php ENDPATH**/ ?>