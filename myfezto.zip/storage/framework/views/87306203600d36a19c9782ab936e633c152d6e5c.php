<?php $__env->startSection('content'); ?>

<div class="main-panel">
<div class="content-wrapper">
<div class="col-12 grid-margin createtable">
              <div class="card">
                <div class="card-body">
           
                  
                        <div class="row">
                        <div class="col-md-6">
                                 <h4 class="card-title">Add Stock</h4>
                        </div>
                           <div class="col-md-6 heading">
                           
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>
                    
                    <div class="row">
                    <br>
                   </div>
                
                  <div class="col-xl-12 col-md-12 col-sm-12 col-12">
           
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div><br />
          <?php endif; ?>
          
        </div>
                  <form class="form-sample"  action="<?php echo e(url('/update-add-product')); ?>" method="post" enctype="multipart/form-data"  id="theform">
                          <?php echo e(csrf_field()); ?>

                    <div class="row">
                        
                <input type="hidden" name="id" value="<?php echo e($ed_prod->id); ?>">



                      <div class="col-md-12">
                        <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Current Stock</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                         <lable style="color:red"> <?php echo e($ed_prod->product_qty); ?></lable>
                          </div>
                        </div>
                      </div>
 

                      <div class="col-md-12">
                        <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Add Stock</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <input type="number" name="stock" id="product_price" class="form-control" step=".001"  required="" min="0">
                                <span id="errmsg" style="color:red;"></span>
                          </div>
                        </div>
                      </div>


                      
             


                        
                      </div>
                
                <div class="submitbutton">
                    <button type="submit" class="btn btn-primary mb-2 submit">Submit<i class="fas fa-save"></i>


</button>
                    </div>
                    
                    
                    
                  </form>
                </div>
              </div>
            </div>
          </div>
            </div>
               
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- <script src="<?php echo e(url('front-end/assets/js/jquery-3.3.1.js')); ?>"></script> -->
<script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script>

<script>
    
  $(function()
  {
  
    $('#theform').submit(function(){
    
    $("input[type='submit']", this)
      
    .val("Please Wait...")
    
    .css("cursor", "not-allowed")
      
    .attr('disabled', 'disabled');
    
    return true;
  
    });
  
});
    

</script>


<script type="text/javascript">

    $(document).ready(function(){
      
     
      // $('textarea').ckeditor();
 
    });
      </script>
         <!-- App functions and actions -->
        <!-- <script src="<?php echo e(url('assets/vendors/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/vendors/bower_components/popper.js/dist/umd/popper.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/vendors/bower_components/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/vendors/bower_components/jquery-scrollLock/jquery-scrollLock.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/vendors/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
         <script src="<?php echo e(url('assets/vendors/bower_components/dropzone/dist/min/dropzone.min.js')); ?>"></script>

        <script src="<?php echo e(url('assets/vendors/bower_components/autosize/dist/autosize.min.js')); ?>"></script> -->

         <!-- <script src="<?php echo e(url('assets/js/app.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/bootstrap-wysiwyg.js')); ?>"></script> -->
        <script>
ClassicEditor
.create( document.querySelector( '#body' ) )
.catch( error => {
console.error( error );
} );
</script>
<script>
ClassicEditor
.create( document.querySelector( '#body1' ) )
.catch( error => {
console.error( error );
} );
</script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>

       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/product/add-stock.blade.php ENDPATH**/ ?>