<?php $__env->startSection('content'); ?>
<div class="main-panel">
<div class="content-wrapper">
<div class="col-12 grid-margin createtable">
              <div class="card">
                <div class="card-body">
           
                  
                        <div class="row">
                        <div class="col-md-6">
                                 <h4 class="card-title">Edit Category</h4>
                        </div>
                           <div class="col-md-6 heading">
                         
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>
                    
                    <div class="row">
                    <br>
                   </div>
                
                  <div class="col-xl-12 col-md-12 col-sm-12 col-12">
           
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div><br />
          <?php endif; ?>
          
        </div>
        <form action="<?php echo e(url('update-values')); ?>" method="post" enctype="multipart/form-data">
                          
                           <?php echo e(csrf_field()); ?>

                    <div class="row">
                    <input type="hidden" name="attr_value_id" value="<?php echo e($attributes_value->attribute_value_id); ?>">

                    <div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label">Attribute Name</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <input type="text" name="attr_val" class="form-control" value="<?php echo e($attributes_value->attribute_value); ?>"  required="">
                          </div>
                        </div>
                      </div>
                                            
                      <div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label"> Category</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <select class="form-control" name="attr_name" required="">
                                         
                                            <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <?php if($attributes_value->attribute_id==$attri->attribute_id): ?>
                                    <option seleted value="<?php echo e($attri->attribute_id); ?>"><?php echo e($attri->attribute_name); ?></option>
                                    <?php else: ?>
                                    <option  value="<?php echo e($attri->attribute_id); ?>"><?php echo e($attri->attribute_name); ?></option>
                                    <?php endif; ?>
                                           

                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                        </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label">Color Code</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <input type="text" name="hex_val_ed" value="<?php echo e($attributes_value->attribute_color_code); ?>" class="form-control">
                          </div>
                        </div>
                      </div>

                      </div>
              
                
                    
                    
                    
                
                <div class="submitbutton">
                    <button type="submit" class="btn btn-primary mb-2 submit">Submit<i class="fas fa-save"></i>


</button>
                    </div>
                    
                
                    
                  </form>
                </div>
              </div>
            </div>
          </div>
            </div>
               
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/attribute_values/edit.blade.php ENDPATH**/ ?>