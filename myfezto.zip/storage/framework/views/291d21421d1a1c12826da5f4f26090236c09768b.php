<?php $__env->startSection('content'); ?>

<div class="main-panel">
<div class="content-wrapper">
<div class="col-12 grid-margin createtable">
              <div class="card">
                <div class="card-body">
           
                  
                        <div class="row">
                        <div class="col-md-6">
                                 <h4 class="card-title">New Size</h4>
                        </div>
                         
                        <div class="col-md-6">
                        </div>
                    </div>
                    
                    <div class="row">
                    <br>
                   </div>
                
                  <div class="col-xl-12 col-md-12 col-sm-12 col-12">
           
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div><br />
          <?php endif; ?>
          
        </div>
                  <form class="form-sample"  action="<?php echo e(url('/add-new-size-product')); ?>" method="post" enctype="multipart/form-data"  id="theform">
                          <?php echo e(csrf_field()); ?>

                    <div class="row">
                        
                    <input type="hidden" name="product_id" class="form-control" value="<?php echo e($view_prod->id); ?>" readonly >
                    <input type="hidden" name="product_code" class="form-control" value="<?php echo e($view_prod->product_id); ?>" readonly >
              

                      
                    <div class="col-md-12">
                        <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Product</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                     
                        <input type="text" name="product_name" id="product_name" class="form-control" value="<?php echo e($view_prod->product_name); ?>"   required="">
                        </div>
                      </div>
                      </div>
                      
                      <div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label">Select Color</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <select class="form-control" name="size_id" required="">
                            <option value="0">Select Size</option>
                             <?php $__currentLoopData = $attribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($attri->attribute_value_id); ?>"><?php echo e($attri->attribute_value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                          </div>
                        </div>
                      </div>


     

                    

                      <div class="col-md-12">
                        <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Product Price</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <input type="number" name="product_price" id="product_price" class="form-control" value="<?php echo e($view_prod->product_price); ?>" step=".001"  required="" min="0">
                                <span id="errmsg" style="color:red;"></span>
                          </div>
                        </div>
                      </div>

           


                      
                      <div class="col-md-12">
                        <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Product Offer Price</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <input type="number" name="product_offer" id="product_price_offer" class="form-control" value="<?php echo e($view_prod->product_price_offer); ?>" step=".001"  required="">
                          </div>
                        </div>
                      </div>

                                       
                      <div class="col-md-12">
                        <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Product Premium Price</label><span style="color:red">*</span>
                          <div class="col-sm-9">
                          <input type="number" name="product_premium_offer" id="product_premium_offer" value="<?php echo e($view_prod->product_premium_offer); ?>" class="form-control" step=".001"  required="">
                          </div>
                        </div>
                      </div>
                   


                      <div class="col-md-12">
                        <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Quantity</label>
                          <div class="col-sm-9">
                          <input type="number" name="product_qty" min="0" max="100" class="form-control"  required=""> 
                          </div>
                        </div>
                      </div>
                     
    

                        
                        
                        
                      </div>
                
                <div class="submitbutton">
                    <button type="submit" class="btn btn-primary mb-2 submit">Submit<i class="fas fa-save"></i>
                    </button>
                    </div>
                    
                    
                    
                  </form>
                </div>
                <div class="table-responsive">
             
                    <table class="table table-hover" >
                      <thead>
                        <tr>
                       
                                  
                                        <th>Size</th>
                                        <th>Product Price</th>
                                        <th>Product Offer Price</th>
                                        <th>Product Premium Price</th>
                                        <th>Product Quandity</th>
                                        <th>Action</th>
                                        
                                       
                        </tr>
                      </thead>
                      <tbody>
                          <?php if($products): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          
                       
                             <td><?php echo e($product->attribute_value); ?></td>
                             <td><?php echo e($product->product_price); ?></td>
                             <td><?php echo e($product->product_price_offer); ?></td>
                             <td><?php echo e($product->product_premium_offer); ?></td>
                             <td><?php echo e($product->available_qty); ?></td>
                            <td> 
                                <!-- <a href="<?php echo e(url('view-product/'.$product->id)); ?>" class="btn btnsmall btn-outline-secondary btn-icon-text" >View</a>
                           
                        <a href="<?php echo e(url('add-image/'.$product->id)); ?>" class="btn btnsmall  btn-outline-secondary btn-icon-text">
                          Add Image
                          <i class="ti-reload btn-icon-prepend"></i>

                        </a> -->
                          </td>
                           
                        </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                       
                      </tbody>
                    </table>
         
                  </div>
              </div>
            </div>
          </div>
            </div>
               
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- <script src="<?php echo e(url('front-end/assets/js/jquery-3.3.1.js')); ?>"></script> -->
<script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script>

<script>
    
  $(function()
  {
  
    $('#theform').submit(function(){
    
    $("input[type='submit']", this)
      
    .val("Please Wait...")
    
    .css("cursor", "not-allowed")
      
    .attr('disabled', 'disabled');
    
    return true;
  
    });
  
});
    

</script>


<script type="text/javascript">

    $(document).ready(function(){
      
     
      // $('textarea').ckeditor();
 
    });
      </script>

        <script>
ClassicEditor
.create( document.querySelector( '#body' ) )
.catch( error => {
console.error( error );
} );
</script>
<script>
ClassicEditor
.create( document.querySelector( '#body1' ) )
.catch( error => {
console.error( error );
} );
</script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>

       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/product/add-size.blade.php ENDPATH**/ ?>