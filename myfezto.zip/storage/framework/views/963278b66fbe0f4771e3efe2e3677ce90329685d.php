
<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
  <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <div class="row ">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                             <h4 class="card-title">View Purchase</h4></h4>
                        </div>
                           <div class="col-md-6 col-sm-6 col-xs-12   heading">
                          
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>
                 
                  <p class="card-description">
                
                  </p>
                  <div class="form-group">
                                <label>Customer</label>
                                <?php
                                $customer = DB::table('customer_registration')
                                            ->where('customer_id',$view_purchase->customer_id)
                                            ->first();
                                ?>
                               
                                <h5><?php echo e($customer->customer_name); ?></h5>
                         
                                <i class="form-group__bar"></i>
                            </div>
                            <div class="form-group">
                              <?php
                              $customer  = DB::table('customer_group')
                                          ->where('group_id','=',$view_purchase->customer_type)
                                          ->get();
                              ?>
                                <label>Customer Type</label>
                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h5><?php echo e($customer->group_name); ?></h5>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <i class="form-group__bar"></i>
                            </div>
                  <div class="table-responsive">
                    <table class="table table-hover" id="value-table">
                      <thead>
                      <tr class="text-uppercase">
                                    <th>ITEM DESCRIPTION</th>
                                    <th>QUANTITY</th>
                                    <th>ADDON</th>
                                    <th>UNIT PRICE</th>
                                    <th>TOTAL</th>
                                </tr>
                      </thead>
                      <tbody>
                      <?php
                                     
                                  $arr_product = $view_purchase->products;

                                  $exp_product = json_decode($arr_product);
                                  $dat = gettype($exp_product);
                                 $tottal ="0";
                                    
                                  ?>
                                 
                                 <?php $__currentLoopData = $exp_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php
                                  $tottal = $tottal+ $exp_product->subtotal;
                                  

                                  ?>


                                    <tr>

                                        <td><?php echo e($exp_product->name); ?> <?php echo e($exp_product->options->size); ?></td>
                                        <td class="text-right"><?php echo e($exp_product->qty); ?></td>
                                       
                                     

                                        <td class="text-right"><?php echo e($exp_product->price); ?></td>
                                        
                                        <td class="text-right"><?php echo e($exp_product->qty*$exp_product->price); ?></td>
                                        <?php  $b = str_replace( ',', '', $tottal ); ?>


                                       
                                    </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                                <tr>
                                        <td class="text-right" colspan="4" >
                                          Shipping Charge
                                        </td>
                                          <?php if($b>=30): ?>
                                    <?php $a='0'; ?>
                                        <td class="text-right">Free</td>

                                        <?php else: ?>
                                          <?php $a='1'; ?>
                                        <td class="text-right">KWD 1.00 </td>

                                        <?php endif; ?>
                                  </tr>
                                  <tr>
                                        <td class="text-right" colspan="4" >
                                          Total Amount
                                        </td>
                                        <td class="text-right">KWD
                                          <?php
                                          echo $b+$a;
                                          ?>
                                        </td>
                                  </tr>

                       
                      </tbody>
                    </table>
                  </div>
                  
                  <div class="form-group">
                                <label>Purchase Date</label>
                                <h5><?php echo e($view_purchase->purchase_date); ?></h5>
                                <i class="form-group__bar"></i>
                            </div>
                </div>
              </div>
            </div>
            </div>
            </div>
            
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
    $('#value-table').DataTable();
} );
let button = document.querySelector("#myexel");

button.addEventListener("click", e => {
  let table = document.querySelector("#value-table");
  TableToExcel.convert(table);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/purchase/view-purchase.blade.php ENDPATH**/ ?>