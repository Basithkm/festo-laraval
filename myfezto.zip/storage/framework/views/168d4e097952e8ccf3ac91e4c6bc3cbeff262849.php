
<?php $__env->startSection('content'); ?>

<div class="main-panel">
<div class="content-wrapper">
<div class="col-12 grid-margin createtable">
              <div class="card">
                <div class="card-body">
           
                  
                        <div class="row">
                        <div class="col-md-6">
                                 <h4 class="card-title">Add Advertisment</h4>
                        </div>
                           <div class="col-md-6 heading">
                             <a href="<?php echo e(URL::to('advertisment')); ?>" class="backicon"><i class="mdi mdi-backburger"></i></a>
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>
                    
                    <div class="row">
                    <br>
                   </div>
                
                  <div class="col-xl-12 col-md-12 col-sm-12 col-12">
           
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div><br />
          <?php endif; ?>
          
        </div>
                  <form class="form-sample"  action="<?php echo e(url('/add-new-ads')); ?>" method="post" enctype="multipart/form-data"  >
                          <?php echo e(csrf_field()); ?>

                    <div class="row">
                        
                      <div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label">Select Page</label>
                          <div class="col-sm-9">
                          <select  name="page" class="form-control" placeholder="Advertisment Page" required="">
                                  <option value="">Select Page</option>
                                     <!-- <option value="accessories-app">App(small) Accessories - 708*369</option> -->
                                    

                                     <option value="men-web">Web(Large) Men - 1349*369</option>
                                     <option value="women-web">Web(Large) Women - 1349*369</option>
                                     <option value="kids-web">Web(Large) Kids - 1349*369</option>
                                     <option value="footweare-web">Web(Large) Footweare - 1349*369</option>
                                     <option value="bags-web">Web(Large) Bags - 1349*369</option>
                                     <option value="kitchen_home-web">Web(Large) Kitchen& Home Appliance - 1349*369</option>
                                     <option value="sports-web">Web(Large) Sports - 1349*369</option>
                                     <option value="toys-web">Web(Large) Toys - 1349*369</option>
                                   

                                </select>
                                <i class="form-group__bar"></i>
                          </div>
                        </div>
                      </div>
                      
                      <div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label">Image</label>
                          <div class="col-sm-9">
                          <input type="file" name="image" id="dropzone-upload" class="dropzone dz-clickable" placeholder="image">
                          </div>
                        </div>
                      </div>
                           
                      <div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label">Product</label>
                          <div class="col-sm-9">
                          <select class="form-control" name="url" required="">
                                    <option value="">----Select Ad URL Link----</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($productss->product_id); ?>"><?php echo e($productss->product_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                          </div>
                        </div>
                      </div>
            

                      </div>
              
                
                    
                    
                    
                
                <div class="submitbutton">
                    <button type="submit" class="btn btn-primary mb-2 submit">Submit<i class="fas fa-save"></i>


</button>
                    </div>
                    
                    
                    
                  </form>
                </div>
              </div>
            </div>
          </div>
            </div>
               
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/advertisment/add-advertisment.blade.php ENDPATH**/ ?>