<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
  <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    
                <div class="row">
                    <div class="col-6 col-md-6 col-sm-6 col-xs-12" >
                             <h4 class="card-title">Product List</h4>
                    </div>
                    <div class="col-6 col-md-6 col-sm-6 col-xs-12 exelbuton" style="text-align:end;">
                             <button type="button" class="btn btn-sm btn-primary toexel" id="myexel" target="_blank"><i class="fa fa-file-excel-o" aria-hidden="true"></i> To Excel</button>
                    </div>
                       
                   
                </div>



                 <!--    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                             <h4 class="card-title">Today Joining</h4></h4>
                        </div>
                        <button type="button" class="btn btn-sm btn-primary" id="myexel" target="_blank"><i class="fa fa-file-excel-o"></i> To Excel</button>

                   
                    </div> -->
                 
                  <p class="card-description">
                
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover" id="value-table">
                      <thead>
                        <tr>
                       
                                  <td></td>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Action</th>
                                        
                                       
                        </tr>
                      </thead>
                      <tbody>
                          
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          
                       <td><a href="<?php echo e(url('view-product/'.$product->id)); ?>" class="btn btnsmall btn-outline-secondary btn-icon-text" >View</a></td>
                             <td><?php echo e($product->product_id); ?></td>
                             <td><?php echo e($product->product_name); ?></td>
                            <td> 
                            <a href="<?php echo e(url('add-color/'.$product->id)); ?>" class="btn btnsmall btn-outline-warning btn-icon-text">
                          Add Color
                          <i class="ti-reload btn-icon-prepend"></i>

                        </a>
                        <a href="<?php echo e(url('add-image/'.$product->id)); ?>" class="btn btnsmall  btn-outline-secondary btn-icon-text">
                          Add Image
                          <i class="ti-reload btn-icon-prepend"></i>

                        </a>
                          </td>
                           
                        </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>
            
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
     $('#value-table').DataTable();
} );
let button = document.querySelector("#myexel");

button.addEventListener("click", e => {
  let table = document.querySelector("#value-table");
  TableToExcel.convert(table);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/product/index.blade.php ENDPATH**/ ?>