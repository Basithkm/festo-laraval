
<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
  <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <div class="row ">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                             <h4 class="card-title">Slider List</h4></h4>
                        </div>
                           <div class="col-md-6 col-sm-6 col-xs-12   heading">
                             <a href="<?php echo e(URL::to('/add-slider-images')); ?>" class="newicon"><i class="mdi mdi-new-box"></i></a>
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>
                 
                  <p class="card-description">
                
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover" id="value-table">
                      <thead>
                      <tr >
                                        <th width="10%">Id</th>
                                        <th width="10%">Language</th>
                                       
                                        <th width="30%">Image</th>                                              
                                        <th>Action</th>
                                    </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr> 
                                        <td><?php echo e($sliders->img_id); ?></td>
                                        <td><?php echo e($sliders->img_for); ?></td>
                                       
                                        <td><img  style="height:70px;border-radius:0px;width:150px;" src="<?php echo e(url('/uploads/home-slider/'.$sliders->img_name)); ?>" alt="" width="100px" ></td>
                <td><a href="<?php echo e(url('delete-slider-image/'.$sliders->img_id)); ?>"  onclick="return confirm('Are you sure you want to delete');" class="btn btn-danger"><i class="zmdi zmdi-delete zmdi-hc-fw"></i>Delete</a></td>
                                    </tr>
                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>
            
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
    $('#value-table').DataTable();
} );
let button = document.querySelector("#myexel");

button.addEventListener("click", e => {
  let table = document.querySelector("#value-table");
  TableToExcel.convert(table);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/home-images/slider_images_list.blade.php ENDPATH**/ ?>