
<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
  <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <div class="row ">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                             <h4 class="card-title">Purchase List</h4></h4>
                        </div>
                           <div class="col-md-6 col-sm-6 col-xs-12   heading">
                          
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>
                 
                  <p class="card-description">
                
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover" id="value-table">
                      <thead>
                        <tr>
                        <th width="5%">Id</th>
                                        <th width="5%">Purchase Id</th>
                                        <th width="20%">User Name</th>
                                       
                                        <th width="15%">Sub Total</th>
                                        <th width="25%">Purchase On</th>                                     
                                        <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php $i='0'; ?>
                                    <?php $__currentLoopData = $purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $i++; ?>
                                    <tr>
                                         <td><?php echo e($i); ?></td>
                                         <td><?php echo e($purchase->purchase_id); ?></td>
                                        <td> <?php
                                $customer = DB::table('customer_registration')
                                            ->where('customer_id',$purchase->customer_id)
                                            ->first();
                                ?><?php echo e($customer->customer_name); ?></td>
                                     
                                        <td><?php echo e($purchase->product_sub_total); ?></td>
                                        <td><?php echo e($purchase->purchase_date); ?></td>
                                        <td>

                                        <a href="<?php echo e(url('view-purchase-list/'.$purchase->purchase_id)); ?>" class="btn btnsmall btn-outline-secondary btn-icon-text"><i class="zmdi zmdi-eye zmdi-hc-fw"></i>View</a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          


                       
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>
            
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
    $('#value-table').DataTable();
} );
let button = document.querySelector("#myexel");

button.addEventListener("click", e => {
  let table = document.querySelector("#value-table");
  TableToExcel.convert(table);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/purchase/purchase.blade.php ENDPATH**/ ?>