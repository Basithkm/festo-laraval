
<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
  <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <div class="row ">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                             <h4 class="card-title">Order List</h4></h4>
                        </div>
                           <div class="col-md-6 col-sm-6 col-xs-12   heading">
                          
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>

                  <p class="card-description">
                
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover" id="value-table">
                      <thead>
                      <tr >
                                        <th width="5%">Id</th>
                                        <th width="14%">Order Number</th>
                                        <th width="19%">Customer Name</th>
                                        <th width="10%">Mobile</th>
                                        <th width="3%">Currency</th>
                                        <th width="8%">Amount</th>
                                        <th width="9%">Status</th>
                                        <th width="20%">Added Date</th>                                     
                                        <th>Action</th>
                                    </tr>
                      </thead>
                      <tbody>
<?php $i='0'; ?>
            <?php $__currentLoopData = $ad_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad_orderss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
          
     <?php $i++; ?>                                <tr>
                                       <td><?php echo e($i); ?></td>
                                        <td><?php echo e($ad_orderss->order_number); ?></td>
                                        <td><?php echo e($ad_orderss->customer_name); ?></td>
                                        <td><?php echo e($ad_orderss->customer_mob); ?></td>
                                        <td><?php echo e($ad_orderss->currency); ?></td>
                                        <td><?php echo e($ad_orderss->total_amnt); ?></td>
                                        <td><?php if($ad_orderss->name=='Canceled'): ?> <span style="color:red;">Canceled</span> <?php elseif($ad_orderss->name=='Complete'): ?> <span style="color:green;">Complete</span> <?php else: ?> <span style="color:blue;"><?php echo e($ad_orderss->name); ?></span>  <?php endif; ?></td>
                                        <td><?php echo e($ad_orderss->created_at); ?></td>


                                        

                                        <td>
                                            
                                    <a href="<?php echo e(url('view-order-list/'.$ad_orderss->order_id)); ?>" class="btn btnsmall btn-outline-secondary btn-icon-text"><i class="zmdi zmdi-eye zmdi-hc-fw"></i>View</a>                                      
                                        </td>
                                    </tr>
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>
            
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
    $('#value-table').DataTable();
} );
let button = document.querySelector("#myexel");

button.addEventListener("click", e => {
  let table = document.querySelector("#value-table");
  TableToExcel.convert(table);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfezto\resources\views/orders/orders.blade.php ENDPATH**/ ?>